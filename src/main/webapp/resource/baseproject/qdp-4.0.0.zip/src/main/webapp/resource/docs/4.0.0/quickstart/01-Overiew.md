QDP Overview
====

## 平台的功能结构

为了提供更大的使用便利，平台目前采用本地运行的方式，可以在本机上运行代码生成平台快速生成平台代码。

-------

##1. 构建工程

###1.1 下载工程模板

下载地址：[QDP 4.0.0](http://120.26.82.66:9090)
![](imgs/01-download-template.png)

###1.2 导入工程模板

下载工程模板后：

1. 解压
2. 修改项目名称（pom.xml）
3. 先使用Maven构建：mvn clean package
4. 运行应用(Springboot)：java -jar target/foss-qdp-project-v4-4.0.0.war
5. 再导入Eclipse

###1.3 使用设计器生成代码

####1.3.1 运行设计器

打开类：com.foreveross.common.util.StartQdpDesignerServer，运行本类，默认的端口：2020。

访问地址：[http://localhost:2020/index.html](http://localhost:2020/index.html)

####1.3.2 配置项目信息 (系统设置->项目根路径)

1. 项目根路径：工程导入的根路径。**路径下必须要有pom.xml**
2. 工程：工程名称，对应maven的artifactId。
3. 包名：工程包名，对应maven的package。
4. 版本：工程版本，对应maven的version。
5. 代码模板版本：1.0.0-vue2-elementui1.3.5

**注意**：上面的配置并不会自动修改pom.xml中的配置，请自行修改。

![](imgs/02-project-config.png)

####1.3.3 导入已有表结构 (系统设置->数据库连接)

1. JdbcUrl：jdbc url。**目前只支持MYSQL数据库**
2. UserName：用户名。
3. Password：密码。
4. 删除：按确定后会加载数据库的表，也可以删除。**删除的表不会影响已经引用的表**

![](imgs/03-project-database.png)

####1.3.4 添加模块

1. 名称：模块的中文名称，如：系统管理。
2. 包名：模块的包名，如：core。**必须符合JAVA包名规范**

![](imgs/04-module-icon.png)

![](imgs/05-module-add.png)

####1.3.5 添加功能

先要选择具体的模块：

1. 名称：模块的中文名称，如：系统管理。
2. 包名：模块的包名，如：core。**必须符合JAVA包名规范**

![](imgs/06-function-icon.png)

![](imgs/07-function-icons.png)


